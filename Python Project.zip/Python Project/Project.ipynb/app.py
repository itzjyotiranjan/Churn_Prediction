import pickle
import pandas as pd
from flask import Flask, request, render_template, jsonify

# Initialize Flask application
app = Flask(__name__)

# Load the trained machine learning model
model_path = 'Project.ipynb/model.sav'
with open(model_path, 'rb') as model_file:
    model = pickle.load(model_file)

# Define the route for the home page
@app.route('/')
def home():
    return render_template('index.html')

# Define the route for making predictions
@app.route('/predict', methods=[ 'POST'])
def predict():
    try:
        # Get input data from the HTML form
        input_data = {
            'Subscription_Length_Months': float(request.form['Subscription_Length_Months']),
            'Monthly_Bill': float(request.form['Monthly_Bill']),
            'Total_Usage_GB': float(request.form['Total_Usage_GB']),
            'Age_group': int(request.form['Age_group']),
            'Gender_Binary': int(request.form['Gender_Binary'])
        }
        
        # Convert input data to a DataFrame
        input_df = pd.DataFrame([input_data])
        
        # Make predictions using the loaded model
        predictions = model.predict(input_df)
        
        # Determine the prediction result
        if predictions[0] == 1:
            result = "This customer is likely to churn."
        else:
            result = "This customer is likely to continue."

        # Render the result in an HTML template
        return render_template('index.html', result=result)
    
    except Exception as e:
        return render_template('index.html', error=str(e))

if __name__ == '__main__':
    app.run(debug=True)
